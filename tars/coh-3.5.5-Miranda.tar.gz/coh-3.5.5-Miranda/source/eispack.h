#ifndef __COMPLEX_H__
#define __COMPLEX_H__
#include <complex>
#endif

int EISPACKUnitaryDiag   (int, double *, double *, double **);
int EISPACKHermiteDiag   (int, complex<double> *, double *, complex<double> *);
