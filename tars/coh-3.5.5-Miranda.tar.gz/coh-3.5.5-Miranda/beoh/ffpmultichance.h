static const int Ne = 40;
static const int Mc =  4;

int FFPReadMultichanceFissionData(const string, const double, double *);

