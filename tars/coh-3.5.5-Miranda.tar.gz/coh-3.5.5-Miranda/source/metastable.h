/*** number of total meta-states for each nucleus to be printed */
static const int MAX_METASTABLE = 5 ;

/*** scan if isomer with T(1/2) > 1ms exists */
static const double thalfmin = 0.001;

