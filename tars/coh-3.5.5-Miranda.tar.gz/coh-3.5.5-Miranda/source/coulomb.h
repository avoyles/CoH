void   coulomb_function (const int, const double, const double, complex<double> *, complex<double> *);
double coulomb_phaseshift (const int, const double);
