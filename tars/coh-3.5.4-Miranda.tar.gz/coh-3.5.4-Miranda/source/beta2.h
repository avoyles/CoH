/*
   beta2.h : 
        read beta2 deformation in FRDM nuclear shape file
 */


#ifndef __DIR_H__
#define __DIR_H_
#include "dir.h"
#endif

/**************************************/
/*      beta2.cpp                     */
/**************************************/
double  beta2Read                     (ZAnumber *);
