#undef RANDOM_SEED_BY_TIME
#undef RANDOM_SEED_BY_PID


/**************************************/
/*      setupinit.cpp                 */
/**************************************/
void    setupInitSystem       (const int, Pdata *);
void    setupScatteringAngle  (void);
int     setupChain            (const int, const double, ZAnumber *, Pdata *);
int     setupCountCompound    (const int);
